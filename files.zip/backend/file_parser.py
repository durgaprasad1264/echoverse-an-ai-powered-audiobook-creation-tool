def parse_uploaded_file(uploaded_file):
    # Supports .txt, .docx, .pdf; returns plain text string
    if uploaded_file.name.endswith('.txt'):
        return uploaded_file.read().decode('utf-8')
    # Add logic for .docx and .pdf as needed
    return "File format not supported yet."