import requests
import config

def synthesize_audio(text, voice):
    payload = {
        "text": text,
        "voice": voice
    }
    response = requests.post(config.WATSON_TTS_API_URL, json=payload, headers={"Authorization": f"Bearer {config.WATSON_API_KEY}"})
    if response.ok:
        # Save or upload audio file, return public URL
        return response.json().get("audio_url", "")
    return ""