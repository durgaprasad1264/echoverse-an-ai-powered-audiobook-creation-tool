import requests
import config

def adapt_tone(text, tone):
    # Example API call to IBM Watson Language Model
    payload = {
        "text": text,
        "tone": tone
    }
    response = requests.post(config.WATSON_LANGUAGE_API_URL, json=payload, headers={"Authorization": f"Bearer {config.WATSON_API_KEY}"})
    if response.ok:
        return response.json().get("adapted_text", "")
    return text