import streamlit as st
from backend.file_parser import parse_uploaded_file
from backend.tone_adapter import adapt_tone
from backend.tts_engine import synthesize_audio

st.title("EchoVerse – AI-Powered Audiobook Creator")

uploaded_file = st.file_uploader("Upload your text file", type=["txt", "docx", "pdf"])
tone = st.selectbox("Select tone", ["neutral", "suspenseful", "inspiring"])
voice = st.selectbox("Select voice", ["Lisa", "Michael", "Allison"])

if uploaded_file:
    text = parse_uploaded_file(uploaded_file)
    st.text_area("Original Text", text, height=200)
    if st.button("Adapt Tone"):
        adapted_text = adapt_tone(text, tone)
        st.text_area("Tone-Adapted Text", adapted_text, height=200)
        if st.button("Generate Audio"):
            audio_url = synthesize_audio(adapted_text, voice)
            st.audio(audio_url)
            st.markdown(f"[Download Audio]({audio_url})")