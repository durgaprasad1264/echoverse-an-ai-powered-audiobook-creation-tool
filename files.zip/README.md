# EchoVerse – AI-Powered Audiobook Creation Tool

## Overview
EchoVerse is a web-based application that transforms written text into professional-quality audiobooks using AI-powered tone adaptation and text-to-speech technology from IBM Watson.

## Features
- Upload text files (.txt, .docx, .pdf)
- Adapt narrative tone (neutral, suspenseful, inspiring)
- Select voice (Lisa, Michael, Allison)
- Download/stream audio output
- Compare original and tone-adapted text side-by-side

## Getting Started
1. Clone the repository
2. Add your IBM Watson API keys to `config.py`
3. Install dependencies: `pip install -r requirements.txt`
4. Run: `streamlit run app.py`

## License
MIT