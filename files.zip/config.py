WATSON_LANGUAGE_API_URL = "https://api.us-south.language-model.watson.cloud.ibm.com/v1/adapt-tone"
WATSON_TTS_API_URL = "https://api.us-south.text-to-speech.watson.cloud.ibm.com/v1/synthesize"
WATSON_API_KEY = "YOUR_IBM_WATSON_API_KEY"