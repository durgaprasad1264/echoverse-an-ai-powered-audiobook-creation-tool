
export type Tone = {
  id: string;
  name: string;
  description: string;
  emoji: string;
};
