import React, { useState, useEffect, useCallback } from 'react';
import { PlayIcon } from './icons/PlayIcon';
import { PauseIcon } from './icons/PauseIcon';
import { StopIcon } from './icons/StopIcon';
import { DownloadIcon } from './icons/DownloadIcon';

interface AudioPlayerProps {
  textToSpeak: string;
  isStreaming: boolean;
}

const AudioPlayer: React.FC<AudioPlayerProps> = ({ textToSpeak, isStreaming }) => {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoice, setSelectedVoice] = useState<SpeechSynthesisVoice | null>(null);

  const populateVoiceList = useCallback(() => {
    const availableVoices = window.speechSynthesis.getVoices();
    if (availableVoices.length > 0) {
      setVoices(availableVoices);
      const defaultVoice = availableVoices.find(v => v.lang.startsWith('en')) || availableVoices[0];
      setSelectedVoice(defaultVoice);
    }
  }, []);

  useEffect(() => {
    populateVoiceList();
    if (window.speechSynthesis.onvoiceschanged !== undefined) {
      window.speechSynthesis.onvoiceschanged = populateVoiceList;
    }

    return () => {
        window.speechSynthesis.cancel();
    }
  }, [populateVoiceList]);

  const handlePlay = () => {
    if (isPaused) {
      window.speechSynthesis.resume();
      setIsPaused(false);
    } else {
      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      if (selectedVoice) {
        utterance.voice = selectedVoice;
      }
      utterance.onend = () => {
        setIsSpeaking(false);
        setIsPaused(false);
      };
      utterance.onerror = (event) => {
        console.error('SpeechSynthesisUtterance.onerror', event);
        setIsSpeaking(false);
        setIsPaused(false);
      };
      window.speechSynthesis.speak(utterance);
    }
    setIsSpeaking(true);
  };

  const handlePause = () => {
    window.speechSynthesis.pause();
    setIsPaused(true);
    setIsSpeaking(false);
  };

  const handleStop = () => {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
    setIsPaused(false);
  };

  const isPlaying = isSpeaking && !isPaused;

  return (
    <div className="bg-gray-900 p-4 rounded-lg border border-gray-700 space-y-4">
      <div className="flex items-center justify-center gap-4">
        {isPlaying ? (
          <button 
            onClick={handlePause} 
            disabled={isStreaming}
            className="p-3 bg-yellow-500 rounded-full text-white hover:bg-yellow-400 disabled:bg-yellow-800 disabled:cursor-not-allowed transition-colors"
            aria-label="Pause narration"
          >
            <PauseIcon className="w-6 h-6" />
          </button>
        ) : (
          <button 
            onClick={handlePlay} 
            disabled={isStreaming || !textToSpeak}
            className="p-3 bg-indigo-600 rounded-full text-white hover:bg-indigo-500 disabled:bg-indigo-900 disabled:cursor-not-allowed transition-colors"
            aria-label="Play narration"
          >
            <PlayIcon className="w-6 h-6" />
          </button>
        )}
        <button 
          onClick={handleStop} 
          disabled={(!isSpeaking && !isPaused) || isStreaming} 
          className="p-3 bg-red-600 rounded-full text-white hover:bg-red-500 disabled:bg-gray-700 disabled:cursor-not-allowed transition-colors"
          aria-label="Stop narration"
        >
          <StopIcon className="w-6 h-6" />
        </button>
      </div>
      <div className="flex flex-col sm:flex-row items-center gap-4">
        <select
          value={selectedVoice?.name || ''}
          onChange={(e) => setSelectedVoice(voices.find(v => v.name === e.target.value) || null)}
          disabled={isStreaming || voices.length === 0}
          className="w-full sm:w-2/3 bg-gray-800 border border-gray-600 text-white rounded-md p-2 focus:ring-indigo-500 focus:border-indigo-500 disabled:bg-gray-700 disabled:text-gray-400 disabled:cursor-not-allowed"
          aria-label="Select voice"
        >
          {voices.length === 0 && <option>Loading voices...</option>}
          {voices.map((voice) => (
            <option key={voice.name} value={voice.name}>
              {voice.name} ({voice.lang})
            </option>
          ))}
        </select>
        <div className="relative w-full sm:w-1/3 group">
          <button 
            disabled 
            className="w-full flex items-center justify-center gap-2 bg-gray-700 text-gray-400 font-semibold py-2 px-4 rounded-lg cursor-not-allowed"
          >
            <DownloadIcon className="w-5 h-5" />
            Download MP3
          </button>
          <div className="absolute bottom-full mb-2 w-full px-2 hidden group-hover:block">
            <div className="bg-gray-700 text-white text-xs rounded py-1 px-2 text-center shadow-lg">
                MP3 download requires a server-side TTS service and is not available in this demo.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AudioPlayer;
